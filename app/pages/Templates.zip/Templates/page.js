"use client";

import React, { useState } from "react";
import { IoIosArrowUp, IoIosArrowDown } from "react-icons/io";
import Image from "next/image";
import Link from "next/link";
import Navbar from "@/app/component/Navbar/page";
import Footer from "@/app/component/Footer/page";

const FilterImages = () => {
  const [openFilter, setOpenFilter] = useState("trending");
  const [selectedFilters, setSelectedFilters] = useState({}); 

  const toggleFilter = (filterName) => {
    setOpenFilter((prev) => (prev === filterName ? null : filterName));
  };

  const handleCheckboxChange = (filterCategory, filterValue) => {
    setSelectedFilters((prevFilters) => {
      const currentCategoryFilters = prevFilters[filterCategory] || [];
      const isValueSelected = currentCategoryFilters.includes(filterValue);
  
      return {
        ...prevFilters,
        [filterCategory]: isValueSelected
          ? currentCategoryFilters.filter((val) => val !== filterValue)
          : [...currentCategoryFilters, filterValue],
      };
    });
  };
  

  const isChecked = (filterCategory, filterValue) =>
    selectedFilters[filterCategory]?.includes(filterValue) || false;

  const handleRemoveAll = () => {
    setSelectedFilters({});
    setOpenFilter(null);
  };

  const [hoveredCard, setHoveredCard] = useState(null);

  const handleMouseEnter = (id) => {
    setHoveredCard(id);
  };

  const handleMouseLeave = () => {
    setHoveredCard(null);
  };

  const collections = [
    {
      id: 1,
      image: "/image/front.jpg",
      image2: "/image/template-1.jpg",
      title: "Edit This Design",
    },
    {
      id: 2,
      image: "/image/front-1.jpg",
      image2: "/image/template-2.jpg",
      title: "Edit This Design",
    },
    {
      id: 3,
      image: "/image/front-2.jpg",
      image2: "/image/template-3.jpg",
      title: "Edit This Design",
    },
    {
      id: 4,
      image: "/image/front-3.jpg",
      image2: "/image/template-4.jpg",
      title: "Edit This Design",
    },
    {
      id: 5,
      image: "/image/front-4.jpg",
      image2: "/image/template-5.jpg",
      title: "Edit This Design",
    },
    {
      id: 6,
      image: "/image/front-5.jpg",
      image2: "/image/template-6.jpg",
      title: "Edit This Design",
    },
    {
      id: 7,
      image: "/image/front-6.jpg",
      image2: "/image/template-7.jpg",
      title: "Edit This Design",
    },
    {
      id: 8,
      image: "/image/front-7.jpg",
      image2: "/image/template-8.jpg",
      title: "Edit This Design",
    },
    {
      id: 9,
      image: "/image/front-11.jpg",
      image2: "/image/template-12.jpg",
      title: "Edit This Design",
    },
    {
      id: 10,
      image: "/image/front-8.jpg",
      image2: "/image/template-9.jpg",
      title: "Edit This Design",
    },
    {
      id: 11,
      image: "/image/front-9.jpg",
      image2: "/image/template-10.jpg",
      title: "Edit This Design",
    },
    {
      id: 12,
      image: "/image/front-10.jpg",
      image2: "/image/template-11.jpg",
      title: "Edit This Design",
    },
  ];


  return (
    <div className="template-section">
      <div className="templates">
        <Navbar />
        <div className="templatesContainer">
          {Object.values(selectedFilters).flat().length > 0 && (
            <div className="selectedFiltersContainer">
          
              <button className="removeAllButton" onClick={handleRemoveAll}>
                Remove All
              </button>

            {Object.keys(selectedFilters).map((category) =>
              selectedFilters[category].map((filter) => (
                <div key={filter} className="selectedFilterBadge">
                  {filter}
                  <button
                    className="removeFilterButton"
                    onClick={() => handleCheckboxChange(category, filter)}
                  >
                    ×
                  </button>
                </div>
              ))
            )}
            </div>
          )}

          <div className="templatesContent">
            <div className="templatesFilter">
              {/* Trending Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("trending")}
                >
                  Trending{" "}
                  <span>
                    {openFilter === "trending" ? (
                      <IoIosArrowUp />
                    ) : (
                      <IoIosArrowDown />
                    )}
                  </span>
                </label>
                {openFilter === "trending" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {["Most Popular", "Mascots", "Nature & Outdoors"].map(
                        (filter) => (
                          <li key={filter}>
                            <label>
                              <input
                                type="checkbox"
                                checked={isChecked("trending", filter)}
                                onChange={() =>
                                  handleCheckboxChange("trending", filter)
                                }
                              />
                              {filter}
                            </label>
                          </li>
                        )
                      )}
                    </ul>
                  </div>
                )}
              </div>

              {/* Parties & Events Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("parties")}
                >
                  Parties & Events{" "}
                  <span>
                    {openFilter === "parties" ? <IoIosArrowUp /> : <IoIosArrowDown />}
                  </span>
                </label>
                {openFilter === "parties" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {[
                        "Most Popular",
                        "Anniversary",
                        "Bachelorette Party",
                        "Beach",
                        "Birthday",
                        "Camp",
                        "Family Reunion",
                      ].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("parties", filter)}
                              onChange={() => handleCheckboxChange("parties", filter)}
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Business Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("business")}
                >
                  Business{" "}
                  <span>
                    {openFilter === "business" ? <IoIosArrowUp /> : <IoIosArrowDown />}
                  </span>
                </label>
                {openFilter === "business" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {[
                        "Most Popular",
                        "Automotive",
                        "Bar / Restaurant",
                        "Construction",
                        "Dance Studios",
                        "Employee Appreciation",
                        "Professional",
                      ].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("business", filter)}
                              onChange={() => handleCheckboxChange("business", filter)}
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* School Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("school")}
                >
                  K-12 School{" "}
                  <span>
                    {openFilter === "school" ? <IoIosArrowUp /> : <IoIosArrowDown />}
                  </span>
                </label>
                {openFilter === "school" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {[
                        "Most Popular",
                        "Athletic Department",
                        "Band / Music",
                        "Choir",
                        "Class Shirts",
                        "Drama",
                        "Find Your Mascot",
                        "Student Council",
                        "Yearbook",
                      ].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("school", filter)}
                              onChange={() => handleCheckboxChange("school", filter)}
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Charities & Fundraisers Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("charities")}
                >
                  Charities & Fundraisers{" "}
                  <span>
                    {openFilter === "charities" ? <IoIosArrowUp /> : <IoIosArrowDown />}
                  </span>
                </label>
                {openFilter === "charities" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {[
                        "Most Popular",
                        "Animal Causes",
                        "Breast Cancer",
                        "Cancer / Health",
                        "Diabetes",
                        "Fundraising Events",
                        "Youth Causes",
                      ].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("charities", filter)}
                              onChange={() => handleCheckboxChange("charities", filter)}
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Holidays & Seasons Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("holidays")}
                >
                  Holidays & Seasons{" "}
                  <span>
                    {openFilter === "holidays" ? <IoIosArrowUp /> : <IoIosArrowDown />}
                  </span>
                </label>
                {openFilter === "holidays" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {["Christmas", "Halloween", "Thanksgiving"].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("holidays", filter)}
                              onChange={() => handleCheckboxChange("holidays", filter)}
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* College Filters */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("college")}
                >
                  College{" "}
                  <span>
                    {openFilter === "college" ? <IoIosArrowUp /> : <IoIosArrowDown />}
                  </span>
                </label>
                {openFilter === "college" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {[
                        "Most Popular",
                        "Clubs",
                        "Department / School",
                        "Find Your Greek Letters",
                      ].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("college", filter)}
                              onChange={() => handleCheckboxChange("college", filter)}
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>



              {/* Sports */}
              <div className="templateFilterGroup">
                <label
                  className="templateFilterName"
                  onClick={() => toggleFilter("sports")}
                >
                  Sports{" "}
                  <span>
                    {openFilter === "sports" ? (
                      <IoIosArrowUp />
                    ) : (
                      <IoIosArrowDown />
                    )}
                  </span>
                </label>
                {openFilter === "sports" && (
                  <div className="templateCustomSelect">
                    <ul className="templateDropdown">
                      {["Baseball", "Basketball", "Football"].map((filter) => (
                        <li key={filter}>
                          <label>
                            <input
                              type="checkbox"
                              checked={isChecked("sports", filter)}
                              onChange={() =>
                                handleCheckboxChange("sports", filter)
                              }
                            />
                            {filter}
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

            </div>

            <div className="templateCards">
            <div className="templateCardsContent">
              {collections.map((item) => (
                <div
                  key={item.id}
                  className="templatecardItem"
                  onMouseEnter={() => handleMouseEnter(item.id)}
                  onMouseLeave={handleMouseLeave}
                >
                  <img
                    src={hoveredCard === item.id ? item.image2 : item.image}
                    alt={item.title}
                    width={300}
                    height={200}
                    className="templatecardImage"
                  />
                  <div className="templateSliderContent">
                    <Link href="/pages/Design">
                      <div className="templateCardInfo">
                        <p>{item.title}</p>
                      </div>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer />
    </div>
  );
};

export default FilterImages;
