"use client";

import React, { useState } from "react";
import { IoIosArrowUp, IoIosArrowDown } from "react-icons/io";
import Image from "next/image";

import Link from "next/link";
import Navbar from "@/app/component/Navbar/page";
import Footer from "@/app/component/Footer/page";

const FilterImages = () => {
  const [openFilter, setOpenFilter] = useState("trending");

  const toggleFilter = (filterName) => {
    setOpenFilter((prev) => (prev === filterName ? null : filterName));
  };

  const handleMoveDetails = () => {
    // Handle click event for each image (e.g., redirect to a details page)
  };

  const [hoveredCard, setHoveredCard] = useState(null);

  const handleMouseEnter = (id) => {
    setHoveredCard(id);
  };

  const handleMouseLeave = () => {
    setHoveredCard(null);
  };

  const collections = [
    {
      id: 1,
      image: "/image/front.jpg",
      image2: "/image/template-1.jpg",
      title: "Edit This Design",
    },
    {
      id: 2,
      image: "/image/front-1.jpg",
      image2: "/image/template-2.jpg",
      title: "Edit This Design",
    },
    {
      id: 3,
      image: "/image/front-2.jpg",
      image2: "/image/template-3.jpg",
      title: "Edit This Design",
    },
    {
      id: 4,
      image: "/image/front-3.jpg",
      image2: "/image/template-4.jpg",
      title: "Edit This Design",
    },
    {
      id: 5,
      image: "/image/front-4.jpg",
      image2: "/image/template-5.jpg",
      title: "Edit This Design",
    },
    {
      id: 6,
      image: "/image/front-5.jpg",
      image2: "/image/template-6.jpg",
      title: "Edit This Design",
    },
    {
      id: 7,
      image: "/image/front-6.jpg",
      image2: "/image/template-7.jpg",
      title: "Edit This Design",
    },
    {
      id: 8,
      image: "/image/front-7.jpg",
      image2: "/image/template-8.jpg",
      title: "Edit This Design",
    },
    {
      id: 9,
      image: "/image/front-11.jpg",
      image2: "/image/template-12.jpg",
      title: "Edit This Design",
    },
    {
      id: 10,
      image: "/image/front-8.jpg",
      image2: "/image/template-9.jpg",
      title: "Edit This Design",
    },
    {
      id: 11,
      image: "/image/front-9.jpg",
      image2: "/image/template-10.jpg",
      title: "Edit This Design",
    },
    {
      id: 12,
      image: "/image/front-10.jpg",
      image2: "/image/template-11.jpg",
      title: "Edit This Design",
    },
  ];

  return (
    <div className="template-section">
    <div className="templates">
      <Navbar />
      <div className="templatesContainer">
        <div className="templatesContent">
          <div className="templatesFilter">
            {/* Trending Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("trending")}
                htmlFor="trending"
              >
                Trending{" "}
                <span>
                  {openFilter === "trending" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "trending" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Mascots</label>
                    </li>
                    <li>
                      <label>Nature & Outdoors</label>
                    </li>
                    <li>
                      <label>Pop Culture</label>
                    </li>
                    <li>
                      <label>Quotes & Phrases</label>
                    </li>
                    <li>
                      <label>Seniors</label>
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* School Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("school")}
                htmlFor="school"
              >
                K-12 School{" "}
                <span>
                  {openFilter === "school" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "school" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Athletic Department</label>
                    </li>
                    <li>
                      <label>Band / Music</label>
                    </li>
                    <li>
                      <label>Choir</label>
                    </li>
                    <li>
                      <label>Class Shirts</label>
                    </li>
                    <li>
                      <label>Drama</label>
                    </li>
                    <li>
                      <label>Find Your Mascot</label>
                    </li>
                    <li>
                      <label>Student Council</label>
                    </li>
                    <li>
                      <label>Yearbook</label>
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* Sports Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("sports")}
                htmlFor="sports"
              >
                Sports{" "}
                <span>
                  {openFilter === "sports" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "sports" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Baseball</label>
                    </li>
                    <li>
                      <label>Basketball</label>
                    </li>
                    <li>
                      <label>Cheerleading</label>
                    </li>
                    <li>
                      <label>Cross Country</label>
                    </li>
                    <li>
                      <label>Football</label>
                    </li>
                    <li>
                      <label>Volleyball</label>
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* Parties & Events Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("parties")}
                htmlFor="parties"
              >
                Parties & Events{" "}
                <span>
                  {openFilter === "parties" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "parties" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Anniversary</label>
                    </li>
                    <li>
                      <label>Bachelorette Party</label>
                    </li>
                    <li>
                      <label>Beach</label>
                    </li>
                    <li>
                      <label>Birthday</label>
                    </li>
                    <li>
                      <label>Camp</label>
                    </li>
                    <li>
                      <label>Family Reunion</label>
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* Business Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("business")}
                htmlFor="business"
              >
                Business{" "}
                <span>
                  {openFilter === "business" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "business" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Automotive</label>
                    </li>
                    <li>
                      <label>Bar / Restaurant</label>
                    </li>
                    <li>
                      <label>Construction</label>
                    </li>
                    <li>
                      <label>Dance Studios</label>
                    </li>
                    <li>
                      <label>Employee Appreciation</label>
                    </li>
                    <li>
                      <label>Professional</label>
                    </li>

                  </ul>
                </div>
              )}
            </div>

            {/* Charities & Fundraisers Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("charities")}
                htmlFor="charities"
              >
                Charities & Fundraisers{" "}
                <span>
                  {openFilter === "charities" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "charities" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Animal Causes</label>
                    </li>
                    <li>
                      <label>Breast Cancer</label>
                    </li>
                    <li>
                      <label>Cancer / Health</label>
                    </li>
                    <li>
                      <label>Diabetes</label>
                    </li>
                    <li>
                      <label>Fundraising Events</label>
                    </li>
                    <li>
                      <label>Youth Causes</label>
                    </li>

                  </ul>
                </div>
              )}
            </div>

            {/* Holidays & Seasons Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("holidays")}
                htmlFor="holidays"
              >
                Holidays & Seasons{" "}
                <span>
                  {openFilter === "holidays" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "holidays" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Christmas</label>
                    </li>
                    <li>
                      <label>Halloween</label>
                    </li>
                    <li>
                      <label>Thanksgiving</label>
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* College Filters */}
            <div className="templateFilterGroup">
              <label
                className="templateFilterName"
                onClick={() => toggleFilter("college")}
                htmlFor="college"
              >
                College{" "}
                <span>
                  {openFilter === "college" ? (
                    <IoIosArrowUp />
                  ) : (
                    <IoIosArrowDown />
                  )}
                </span>
              </label>
              {openFilter === "college" && (
                <div className="templateCustomSelect">
                  <ul className="templateDropdown">
                    <li>
                      <label>Most Popular</label>
                    </li>
                    <li>
                      <label>Clubs</label>
                    </li>
                    <li>
                      <label>Department / School</label>
                    </li>
                    <li>
                      <label>Find Your Greek Letters</label>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div className="templateCards">
            <div className="templateCardsContent">
              {collections.map((item) => (
                <div
                  key={item.id}
                  className="templatecardItem"
                  onMouseEnter={() => handleMouseEnter(item.id)}
                  onMouseLeave={handleMouseLeave}
                >
                  <img
                    src={hoveredCard === item.id ? item.image2 : item.image}
                    alt={item.title}
                    width={300}
                    height={200}
                    className="templatecardImage"
                  />
                  <div className="templateSliderContent">
                    <Link href="/">
                      <div className="templateCardInfo">
                        <p>{item.title}</p>
                      </div>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer />
    </div>
  );
};

export default FilterImages;
